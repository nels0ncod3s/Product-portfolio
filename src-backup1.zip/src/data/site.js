// One place for the details that show up in several sections.
// Anything with an empty href is hidden automatically.
export const site = {
  name: 'Nelson Wey',
  email: 'oluwademiladewey@gmail.com',
  location: 'Lagos, Nigeria',
  timeZone: 'Africa/Lagos',
  socials: [
    { label: 'GitHub', href: 'https://github.com/nels0ncod3s' }, // check this handle
    { label: 'X', href: 'https://x.com/heynelsonwey' },
    { label: 'LinkedIn', href: '' },
    // Put your CV in /public (e.g. public/Nelson-Wey-CV.pdf), then set the href
    // below to '/Nelson-Wey-CV.pdf'. It stays hidden while this is empty.
    { label: 'CV', href: '' },
  ],
};
