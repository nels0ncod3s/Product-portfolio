// Case studies, keyed by the `slug` of a project in selectedWork.jsx.
// A project only gets a "Read case study" button if its slug appears here.
//
// DRAFT: every line below must be checked by you. Only keep what is true and
// current. No invented numbers, users or results. To add another case study,
// copy the block, change the key, and add `slug: '...'` to the project.
export const caseStudies = {
  'first-layer': {
    tagline: 'Hosted authentication for developers.',
    role: 'Solo: product, design and engineering',
    stack: ['SvelteKit', 'Fastify', 'Supabase', 'npm SDK'],
    links: [{ label: 'Live product', href: 'https://usefirstlayer.vercel.app/' }],
    sections: [
      {
        heading: 'The problem',
        body: [
          'Every app needs sign-up, login and sessions, and every team ends up building them again. It is repetitive, security-sensitive work that gets in the way of the product they actually want to make.',
        ],
      },
      {
        heading: 'What I built',
        list: [
          'A hosted authentication API that an app talks to with a single API key.',
          'A dashboard to manage projects, users and API keys, including bulk user management.',
          'An npm SDK (@firstlayer/sdk): create a client with nothing but an API key.',
          'A marketing site with pricing, a changelog and docs.',
        ],
      },
      {
        heading: 'Decisions that mattered',
        list: [
          'Opaque session tokens instead of JWTs. A token is just a lookup in a sessions table, so a session can be revoked instantly. A signed JWT is hard to take back before it expires.',
          'A Stripe-style SDK. The base URL is built in and the only thing a developer supplies is an API key, so setup is a couple of lines.',
          'Project-scoped dashboard routes (/dashboard/[project]). Every user, key and setting belongs to one project, and the URL always says which.',
          'Built for people who live in their tools: a ⌘K command palette and toast feedback on every action.',
        ],
      },
      {
        heading: 'Stack',
        body: [
          'SvelteKit for the dashboard, Fastify for the API and Supabase for the database. The dashboard is deployed on Vercel and the API on pxxl.app.',
        ],
      },
      {
        heading: 'What I learned',
        list: [
          'Linux hosts are case-sensitive. A file whose name differed only by letter case worked on my machine and broke the production build, so I now check file naming before every deploy.',
          'Fix bugs by category, not one at a time. A full audit of the dashboard found seven kinds of bug (table-name casing and a dark mode that never switched on, among them), and I fixed each kind everywhere at once.',
        ],
      },
    ],
  },

  // DRAFT. The facts (camera-first, photos pinned to a map, the drop animation,
  // React Native + Expo, freemium with Drift+, the SDK lesson) are real, but the
  // reasoning under "Decisions that mattered" is a guess at your thinking.
  // Rewrite it in your own words, and update `status` to match reality.
  drift: {
    tagline: 'A camera-first photo journal that pins every photo to the place it was taken.',
    role: 'Solo: product, design and engineering',
    status: 'In development',
    stack: ['React Native'],
    links: [],
    sections: [
      {
        heading: 'The idea',
        body: [
          'Photo apps organise memories by date. Drift organises them by place: you take a photo, it is pinned to where it happened, and over time your map becomes a journal of your life.',
        ],
      },
      {
        heading: 'What I built',
        list: [
          'A camera-first flow: the app opens straight to the camera, so capturing a moment takes one tap.',
          'Photos pinned to locations on a map, so you browse memories by where they happened.',
          'A signature drop animation: each photo lands on the map with a small, physical bounce, built with react-native-reanimated.',
          'A freemium model, with a paid Drift+ tier.',
        ],
      },
      {
        heading: 'Decisions that mattered',
        list: [
          'Camera first, gallery second. The moment you want to keep is the moment you open the app, so nothing sits between you and the shutter.',
          'Place, not date, as the organising idea. It is the one thing a camera roll sorted by time cannot give you.',
          'One signature animation instead of many small ones. The drop is the moment the app feels alive, so that is where the polish went.',
        ],
      },
      {
        heading: 'Stack',
        body: ['React Native with Expo, and react-native-reanimated for the animations.'],
      },
      {
        heading: 'What I learned',
        list: [
          'Expo Go and the project have to be on the same SDK version. A mismatch (Expo Go on SDK 54 against a project on SDK 57) stops the app from loading, and the fix is a clean reset with matching versions, not a patch.',
        ],
      },
    ],
  },
};
