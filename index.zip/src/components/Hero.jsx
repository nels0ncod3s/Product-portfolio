
function Hero() {
  return (
    <section className="hero" id="home">
      <div className="hero-topline">
        <span>INDEPENDENT PRODUCT DESIGNER</span>
        <span>LAGOS, NIGERIA</span>
      </div>

      <div className="hero-center">
        <span className="hero-intro">
          HELLO, I'M
        </span>

        <h1>
          Nelson <span>Wey.</span>
        </h1>

        <p className="hero-description">
          I’m a product designer and developer passionate about
          creating thoughtful digital experiences that solve
          real problems and make everyday interactions better.
        </p>

        <a href="#work" className="hero-scroll-link">
          EXPLORE MY WORK <span>↘</span>
        </a>
      </div>

      <div className="hero-index">
        <span>PORTFOLIO / 2026</span>
        <span>SCROLL TO EXPLORE ↓</span>
      </div>
    </section>
  );
}

export default Hero;
