
import { useEffect, useState } from 'react';
import './Preloader.css';

function Preloader({ onComplete }) {
  const [count, setCount] = useState(0);
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const reducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    if (reducedMotion) {
      onComplete();
      return;
    }

    const start = performance.now();
    const duration = 1200;
    let frame;
    let exitTimer;

    function animate(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      setCount(Math.round(eased * 100));

      if (progress < 1) {
        frame = requestAnimationFrame(animate);
      } else {
        setExiting(true);

        exitTimer = setTimeout(() => {
          onComplete();
        }, 600);
      }
    }

    frame = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(frame);
      clearTimeout(exitTimer);
    };
  }, [onComplete]);

  return (
    <div className={`preloader ${exiting ? 'exiting' : ''}`}>
      <div className="preloader-panels">
        {[0, 1, 2, 3].map((panel) => (
          <span key={panel} style={{ '--i': panel }} />
        ))}
      </div>

      <div className="preloader-content">
        <div className="preloader-label">
          <span>Nelson Wey</span>
          <span>PORTFOLIO 2026</span>
        </div>

        <div className="preloader-counter">
          {String(count).padStart(3, '0')}
          <span>%</span>
        </div>

        <div className="preloader-track">
          <div
            className="preloader-progress"
            style={{ transform: `scaleX(${count / 100})` }}
          />
        </div>

        
      </div>
    </div>
  );
}

export default Preloader;
