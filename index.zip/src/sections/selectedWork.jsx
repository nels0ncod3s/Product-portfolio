
const projects = [
  {
    number: '01',
    name: 'First Layer',
    category: 'Developer Tools · Product Design',
    description: 'Making authentication simpler for developers.',
    year: '2026',
    className: 'project-one',
  },
  {
    number: '02',
    name: 'Routly',
    category: 'Travel · Product Design',
    description: 'A better way to plan and navigate journeys.',
    year: '2026',
    className: 'project-two',
  },
  {
    number: '03',
    name: 'Buy Me Zobo',
    category: 'Fintech · Product Design',
    description: 'Helping creators receive support from their audience.',
    year: '2026',
    className: 'project-three',
  },
];

function SelectedWork() {
  return (
    <section className="work-section" id="work">
      <div className="section-heading">
        <div>
          <span className="eyebrow">A FEW THINGS I'VE MADE</span>
          <h2>Selected work<span>.</span></h2>
        </div>

        <p>2025 — 2026</p>
      </div>

      <div className="project-list">
        {projects.map((project) => (
          <article className="project-card" key={project.number}>
            <div className={`project-visual ${project.className}`}>
              <span>{project.name}</span>
              <span className="project-arrow">↗</span>
            </div>

            <div className="project-info">
              <div>
                <span className="project-number">{project.number}</span>
                <h3>{project.name}</h3>
                <p>{project.description}</p>
              </div>

              <div className="project-meta">
                <span>{project.category}</span>
                <span>{project.year}</span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export default SelectedWork;
