
function Contact() {
  return (
    <section className="contact-section" id="contact">
      <span className="eyebrow">HAVE SOMETHING IN MIND?</span>

      <h2>
        Let's make
        <br />
        something <span>meaningful.</span>
      </h2>

      <a href="mailto:hello@example.com" className="contact-link">
        GET IN TOUCH ↗
      </a>

      <footer>
        <span>© 2026 NELSON WEY</span>
        <span>DESIGNED WITH INTENTION.</span>
        <a href="#home">BACK TO TOP ↑</a>
      </footer>
    </section>
  );
}

export default Contact;
