
function About() {
  return (
    <section className="about-section" id="about">
      <span className="eyebrow">A LITTLE ABOUT ME</span>

      <div className="about-content">
        <h2>
          Curious about people,
          <br />
          obsessed with solving
          <br />
          <span>problems.</span>
        </h2>

        <div className="about-description">
          <p>
            I'm Nelson, a digital product designer interested
            in creating meaningful experiences through
            thoughtful design and technology.
          </p>

          <p>
            I enjoy exploring how people interact with
            digital products and finding opportunities
            to make those experiences better.
          </p>
        </div>
      </div>
    </section>
  );
}

export default About;
