
import { useState } from 'react';
import Preloader from './components/preloader';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import SelectedWork from './sections/selectedWork';
import About from './sections/About';
import Contact from './sections/Contact';

function App() {
  const [loading, setLoading] = useState(true);

  return (
    <>
      {loading && <Preloader onComplete={() => setLoading(false)} />}

      <Navbar />

      <main>
        <Hero />
        <SelectedWork />
        <About />
        <Contact />
      </main>
    </>
  );
}

export default App;
